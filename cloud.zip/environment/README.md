         ___        ______     ____ _                 _  ___  
        / \ \      / / ___|   / ___| | ___  _   _  __| |/ _ \ 
       / _ \ \ /\ / /\___ \  | |   | |/ _ \| | | |/ _` | (_) |
      / ___ \ V  V /  ___) | | |___| | (_) | |_| | (_| |\__, |
     /_/   \_\_/\_/  |____/   \____|_|\___/ \__,_|\__,_|  /_/ 
 ----------------------------------------------------------------- 


Hi there! Welcome to AWS Cloud9!

To get started, create some files, play with the terminal,
or visit https://docs.aws.amazon.com/console/cloud9/ for our documentation.

Happy coding!

#Steps to deploy basic part of the required infrastructure via Terraform
1. Create a key pair named "A4KP"
2. Load main.tf into the root folder
3. Load dev and shared folders into the root folder
4. Run "terraform init" in the terminal
5. Run " terraform plan" in the terminal
6. Run " terraform apply" in the terminal
7. Check
